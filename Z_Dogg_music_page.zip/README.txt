# Z Dogg Music Page

This folder is ready for GitHub Pages.

## Publish it
1. Create a new GitHub repository.
2. Upload `index.html` and the `songs` folder (including both audio files).
3. In the repository, open Settings → Pages.
4. Set the source to deploy from the `main` branch and `/ (root)`.
5. GitHub will give you a public Pages address.

The page already has five spaces: two current songs and three future-song slots.
